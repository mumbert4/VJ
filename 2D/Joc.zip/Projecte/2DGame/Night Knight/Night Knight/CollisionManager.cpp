#include "CollisionManager.h"


bool CollisionManager::collisionEnemy() {



}